# Dataset

The notebook uses `heart-disease.csv`.

The original uploaded project loads this dataset from the following public
source:

https://raw.githubusercontent.com/mrdbourke/zero-to-mastery-ml/master/data/heart-disease.csv

Download the CSV and place it in this folder if you want the notebook to run
without relying on the remote URL.

The data is based on the Cleveland heart disease dataset.

Do not treat the dataset or model as medical advice.
