# Heart Disease Classification

A machine learning classification project that predicts whether heart disease
is present using clinical patient features.

## Objective

Build and evaluate classification models using patient clinical parameters and
identify a model suitable for a proof-of-concept.

## Dataset

- 303 records
- 13 input features
- 1 target feature (`target`)
- `1` = heart disease present
- `0` = heart disease not present

The dataset used in the original notebook is the formatted
`heart-disease.csv` dataset from the Zero to Mastery ML repository.

Dataset source:
https://raw.githubusercontent.com/mrdbourke/zero-to-mastery-ml/master/data/heart-disease.csv

## Models

- K-Nearest Neighbors
- Logistic Regression
- Random Forest

## Techniques Used

- Exploratory Data Analysis
- Train/Test Split
- Model Comparison
- Hyperparameter Tuning
- RandomizedSearchCV
- GridSearchCV
- 5-Fold Cross-Validation
- ROC Curve and ROC-AUC
- Confusion Matrix
- Classification Report
- Feature Importance

## Results

The tuned Logistic Regression model achieved approximately:

| Metric | Result |
|---|---:|
| Test Accuracy | 88.5% |
| F1 Score | 0.89 |
| ROC-AUC | 0.92 |
| Mean CV Accuracy | 84.8% |
| Mean CV F1 | 0.87 |

The initial proof-of-concept target was 95% accuracy, which was not reached.

## Project Structure

```text
Project-01-Heart-Disease-Classification/
│
├── README.md
├── requirements.txt
├── .gitignore
│
├── notebooks/
│   └── heart_disease_classification.ipynb
│
├── data/
│   └── README.md
│
└── images/
    └── README.md
```

## How to Run

```bash
pip install -r requirements.txt
```

Then open:

```text
notebooks/heart_disease_classification.ipynb
```

The notebook first looks for:

```text
data/heart-disease.csv
```

If the file is not present, it loads the public dataset URL directly.

## Disclaimer

This is an educational machine learning project. It is not intended for
medical diagnosis or clinical decision-making.

## Author

Yatharth Goyal
